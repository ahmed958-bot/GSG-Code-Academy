# GSG Code Academy

Admin hub for the code academy, specifically a place to put public application steps which can be easily changed.

See [this document](./technical-tasks.md) for the current technical tasks needed to apply.

---

Many of the pre-requisite materials are adapted from [The Odin Project](https://github.com/TheOdinProject/curriculum), written by Erik Trautman.
