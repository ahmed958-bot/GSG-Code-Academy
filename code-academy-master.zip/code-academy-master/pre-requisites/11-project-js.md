### JavaScript Project

Well done on learning all the basics of JavaScript! Now you need to practice!

When you signed up to do technical tasks for this application you should have received an email telling you which project has been randomly assigned to you - go and find that email to know what project to do next. The subject line in the email will have been `GSG Code Academy Technical Tasks & JavaScript Project` so search your inbox for that. You should also check your spam/junk filter if you cannot find it.

If you have trouble please email the team who will be able to help.

You can find all of the projects [here](./projects/). If you want more practice, we will be very impressed if you do an extra project or 2!
