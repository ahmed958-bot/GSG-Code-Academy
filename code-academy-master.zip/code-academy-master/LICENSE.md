Licensed under [Creative Commons License](https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode).
